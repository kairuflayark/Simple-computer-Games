	#include "velocity.h"
	#include <cmath>



	// void setMagnitudeAndDirection( float magnitude, float direction)
	// {
	// 	float angleRadians = deg2rad(angle);

	// 	dx= cos(angleRadians) * magnitude;
	// 	dy = -sin(angleRadians) * magnitude;
	// }

	// void setDirection(float direction){}
	// void setMagnitude(float magnitude){}

	// float getMagnitude() const {}
	// float getDirection() const {}