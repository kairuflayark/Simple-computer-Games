

#include "flyingObject.h"




	/********************************************
	* default constructor
	********************************************/
	FlyingObject::FlyingObject()
	{
		alive = true;
		point = Point();
		velocity = Velocity();


	}

	/********************************************
	* default destructor
	********************************************/
	FlyingObject::~FlyingObject()
	{

		
	}